let btn = document.querySelector('.inputButton')
// console.log('rand', rand);
let tryNumber = 1
let value = 0
let win = 100
let input = document.querySelector('.inputNumber')

document.querySelector('.main_block button').onclick = start

function start() {
    document.querySelector('.main_block').style.display = 'none';
    document.querySelector('.input_block').style.display = 'block';
} 

function getNumUser() {
    let inputUserNum = Number(input.value)
    console.log(inputUserNum);
    return inputUserNum
}

btn.addEventListener('click', compareResults)

function compareResults() {
    console.log(getNumUser());
    let rand = randNumber()
    document.querySelector('.input_block h4 span').textContent = rand
    console.log('rand', rand);
        if(rand == getNumUser()) {
            winGame(130);
            // setGameOver()
        // } else if (tryNumber == 4) {
             // else if (tryNumber) {
        //     console.log(tryNumber);
        } else {
            console.log('Количество спроб ', tryNumber++)
            let continueGame = confirm("you lose? But you have 2nd chanse!..");
            
            if(continueGame) {
            // let rand2 = randNumber()
            // console.log('rand2', rand2);
                if(rand == getNumUser()) {
                    console.log(tryNumber);
                    winGame(50)
                    if (tryNumber == 2) {
                        // value += (win / 2)
                        // priceOfGame(value)
                    }
                // } else if (tryNumber == 4) {
                }        
            } // end Continue 2
        }
    console.log('rand at end', rand);
    // console.log('Новое рандомное', rand = randNumber());
    input.value = ''

}

function setGameOver() {
    document.querySelector('.main_block').style.display = 'block';
    document.querySelector('.input_block').style.display = 'none';
    document.querySelector('.main_block button').textContent = 'Start new game';
}
function resetGame() {
  guessCount = 1;
  const resetParas = document.querySelectorAll('.resultParas p');
  for(let i = 0 ; i < resetParas.length ; i++) {
    resetParas[i].textContent = '';
  }

  resetButton.parentNode.removeChild(resetButton);
  
  input.value = '';
  randomNumber = Math.floor(Math.random() * 100) + 1;
}

console.log('====================');     

function winGame(currentWin = 100) {
    // console.log('rand equel', rand);
    // console.log('rand2 equel', rand2);
    value += currentWin
    priceOfGame(value)
    alert(`You win ${currentWin}$`)
    tryNumber = 1 
}      

// function randNumber() {
//     let rand = Math.floor(1 + Math.random() * (6 + 1 - 1))

//     console.log('start fn rand:', rand);
//     return rand
// }

function randNumber(max  = 6) {
	const min = 2;
	let rand = Math.floor(min + Math.random() * (max + 1 - min))
	console.log(rand);
	return rand = 2
	return rand
}
// randNumber()
function priceOfGame(value) {
    console.log(value);
    return document.querySelector('.gameWins').innerText = value
}

function gameOver() {
    
}
